/****************************************************************************
** Meta object code from reading C++ file 'xform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "xform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'xform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_XFormView_t {
    QByteArrayData data[30];
    char stringdata0[293];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_XFormView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_XFormView_t qt_meta_stringdata_XFormView = {
    {
QT_MOC_LITERAL(0, 0, 9), // "XFormView"
QT_MOC_LITERAL(1, 10, 15), // "rotationChanged"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 8), // "rotation"
QT_MOC_LITERAL(4, 36, 12), // "scaleChanged"
QT_MOC_LITERAL(5, 49, 5), // "scale"
QT_MOC_LITERAL(6, 55, 12), // "shearChanged"
QT_MOC_LITERAL(7, 68, 5), // "shear"
QT_MOC_LITERAL(8, 74, 12), // "setAnimation"
QT_MOC_LITERAL(9, 87, 7), // "animate"
QT_MOC_LITERAL(10, 95, 16), // "updateCtrlPoints"
QT_MOC_LITERAL(11, 112, 14), // "changeRotation"
QT_MOC_LITERAL(12, 127, 11), // "changeScale"
QT_MOC_LITERAL(13, 139, 11), // "changeShear"
QT_MOC_LITERAL(14, 151, 7), // "setText"
QT_MOC_LITERAL(15, 159, 9), // "setPixmap"
QT_MOC_LITERAL(16, 169, 7), // "setType"
QT_MOC_LITERAL(17, 177, 9), // "XFormType"
QT_MOC_LITERAL(18, 187, 1), // "t"
QT_MOC_LITERAL(19, 189, 13), // "setVectorType"
QT_MOC_LITERAL(20, 203, 13), // "setPixmapType"
QT_MOC_LITERAL(21, 217, 11), // "setTextType"
QT_MOC_LITERAL(22, 229, 5), // "reset"
QT_MOC_LITERAL(23, 235, 4), // "type"
QT_MOC_LITERAL(24, 240, 9), // "animation"
QT_MOC_LITERAL(25, 250, 4), // "text"
QT_MOC_LITERAL(26, 255, 6), // "pixmap"
QT_MOC_LITERAL(27, 262, 10), // "VectorType"
QT_MOC_LITERAL(28, 273, 10), // "PixmapType"
QT_MOC_LITERAL(29, 284, 8) // "TextType"

    },
    "XFormView\0rotationChanged\0\0rotation\0"
    "scaleChanged\0scale\0shearChanged\0shear\0"
    "setAnimation\0animate\0updateCtrlPoints\0"
    "changeRotation\0changeScale\0changeShear\0"
    "setText\0setPixmap\0setType\0XFormType\0"
    "t\0setVectorType\0setPixmapType\0setTextType\0"
    "reset\0type\0animation\0text\0pixmap\0"
    "VectorType\0PixmapType\0TextType"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_XFormView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       7,  126, // properties
       1,  147, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x06 /* Public */,
       4,    1,   92,    2, 0x06 /* Public */,
       6,    1,   95,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,   98,    2, 0x0a /* Public */,
      10,    1,  101,    2, 0x0a /* Public */,
      11,    1,  104,    2, 0x0a /* Public */,
      12,    1,  107,    2, 0x0a /* Public */,
      13,    1,  110,    2, 0x0a /* Public */,
      14,    1,  113,    2, 0x0a /* Public */,
      15,    1,  116,    2, 0x0a /* Public */,
      16,    1,  119,    2, 0x0a /* Public */,
      19,    0,  122,    2, 0x0a /* Public */,
      20,    0,  123,    2, 0x0a /* Public */,
      21,    0,  124,    2, 0x0a /* Public */,
      22,    0,  125,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    7,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::QPolygonF,    2,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QPixmap,    2,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      23, 0x80000000 | 17, 0x0009510b,
      24, QMetaType::Bool, 0x00095103,
       7, QMetaType::QReal, 0x00095103,
       3, QMetaType::QReal, 0x00095103,
       5, QMetaType::QReal, 0x00095103,
      25, QMetaType::QString, 0x00095103,
      26, QMetaType::QPixmap, 0x00095103,

 // enums: name, alias, flags, count, data
      17,   17, 0x0,    3,  152,

 // enum data: key, value
      27, uint(XFormView::VectorType),
      28, uint(XFormView::PixmapType),
      29, uint(XFormView::TextType),

       0        // eod
};

void XFormView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<XFormView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->rotationChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->scaleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->shearChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->setAnimation((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->updateCtrlPoints((*reinterpret_cast< const QPolygonF(*)>(_a[1]))); break;
        case 5: _t->changeRotation((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->changeScale((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->changeShear((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->setText((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->setPixmap((*reinterpret_cast< const QPixmap(*)>(_a[1]))); break;
        case 10: _t->setType((*reinterpret_cast< XFormType(*)>(_a[1]))); break;
        case 11: _t->setVectorType(); break;
        case 12: _t->setPixmapType(); break;
        case 13: _t->setTextType(); break;
        case 14: _t->reset(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (XFormView::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&XFormView::rotationChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (XFormView::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&XFormView::scaleChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (XFormView::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&XFormView::shearChanged)) {
                *result = 2;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<XFormView *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< XFormType*>(_v) = _t->type(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->animation(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->shear(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->rotation(); break;
        case 4: *reinterpret_cast< qreal*>(_v) = _t->scale(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->text(); break;
        case 6: *reinterpret_cast< QPixmap*>(_v) = _t->pixmap(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<XFormView *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setType(*reinterpret_cast< XFormType*>(_v)); break;
        case 1: _t->setAnimation(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setShear(*reinterpret_cast< qreal*>(_v)); break;
        case 3: _t->setRotation(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setScale(*reinterpret_cast< qreal*>(_v)); break;
        case 5: _t->setText(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setPixmap(*reinterpret_cast< QPixmap*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject XFormView::staticMetaObject = { {
    &ArthurFrame::staticMetaObject,
    qt_meta_stringdata_XFormView.data,
    qt_meta_data_XFormView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *XFormView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *XFormView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_XFormView.stringdata0))
        return static_cast<void*>(this);
    return ArthurFrame::qt_metacast(_clname);
}

int XFormView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ArthurFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void XFormView::rotationChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void XFormView::scaleChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void XFormView::shearChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
struct qt_meta_stringdata_XFormWidget_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_XFormWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_XFormWidget_t qt_meta_stringdata_XFormWidget = {
    {
QT_MOC_LITERAL(0, 0, 11) // "XFormWidget"

    },
    "XFormWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_XFormWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void XFormWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject XFormWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_XFormWidget.data,
    qt_meta_data_XFormWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *XFormWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *XFormWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_XFormWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int XFormWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
